# egg detection 3 > 2025-06-11 11:30am
https://universe.roboflow.com/eggs-hcgmj/egg-detection-3

Provided by a Roboflow user
License: CC BY 4.0

